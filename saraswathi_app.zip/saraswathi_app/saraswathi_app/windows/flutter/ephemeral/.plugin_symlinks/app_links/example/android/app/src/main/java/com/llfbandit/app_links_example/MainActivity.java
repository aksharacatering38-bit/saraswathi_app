package com.llfbandit.app_links_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {}